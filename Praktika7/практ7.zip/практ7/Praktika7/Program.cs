﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        while (true)
        {
            Console.WriteLine(
                "\n1. События и анализ чисел\n" +
                "2. Предложения и замена символов\n" +
                "3. Сортировка и поиск\n0. Выход");

            string? choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1": Task1(); break;
                    case "2": Task2(); break;
                    case "3": Task3(); break;
                    case "0": return;
                    default: Console.WriteLine("Неверный номер."); break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
        }
    }

    // Задание 1. Событие и анализ чисел
    static void Task1()
    {
        int[] numbers = new int[1000];
        using ManualResetEvent ready = new(false);

        Thread generator = new(() =>
        {
            Random random = new();

            for (int i = 0; i < numbers.Length; i++)
                numbers[i] = random.Next(0, 5001);

            Console.WriteLine("Сгенерировано 1000 чисел.");
            ready.Set();
        });

        Thread maximum = new(() =>
        {
            ready.WaitOne();
            Console.WriteLine("Максимум: " + numbers.Max());
        });

        Thread minimum = new(() =>
        {
            ready.WaitOne();
            Console.WriteLine("Минимум: " + numbers.Min());
        });

        Thread average = new(() =>
        {
            ready.WaitOne();
            Console.WriteLine($"Среднее: {numbers.Average():F2}");
        });

        maximum.Start();
        minimum.Start();
        average.Start();
        generator.Start();

        generator.Join();
        maximum.Join();
        minimum.Join();
        average.Join();
    }

    // Задание 2. Подсчёт предложений и изменение файла
    static void Task2()
    {
        Console.Write("Полный путь к текстовому файлу: ");
        string path = Path.GetFullPath(
            (Console.ReadLine() ?? "").Trim().Trim('"'));

        object sync = new();
        bool finished = false;
        Exception? error = null;
        string text = "";

        Thread reader = new(state =>
        {
            lock (sync)
            {
                try
                {
                    string file = (string)state!;
                    text = File.ReadAllText(file, Encoding.UTF8);

                    // Конец предложения: . ! ? или их сочетание.
                    // Последний текст без знака тоже учитываем.
                    int count = Regex.Split(text, @"[.!?]+")
                        .Count(part => part.Any(char.IsLetterOrDigit));

                    Console.WriteLine("Предложений: " + count);
                }
                catch (Exception ex)
                {
                    error = ex;
                }
                finally
                {
                    finished = true;
                    Monitor.PulseAll(sync);
                }
            }
        });

        Thread editor = new(() =>
        {
            lock (sync)
            {
                while (!finished)
                    Monitor.Wait(sync);

                if (error != null) return;

                try
                {
                    string backup = path + "." +
                        Guid.NewGuid().ToString("N") + ".bak";

                    File.Copy(path, backup);
                    File.WriteAllText(
                        path, text.Replace('!', '#'), Encoding.UTF8);

                    Console.WriteLine("Все ! заменены на #.");
                    Console.WriteLine("Исходный файл сохранён: " + backup);
                }
                catch (Exception ex)
                {
                    error = ex;
                }
            }
        });

        editor.Start();
        reader.Start(path);

        reader.Join();
        editor.Join();

        if (error != null)
            Console.WriteLine("Ошибка работы с файлом: " + error.Message);
    }

    // Задание 3. Сортировка массива и поиск числа
    static void Task3()
    {
        Console.Write("Введите целые числа через пробел: ");
        int[] numbers = (Console.ReadLine() ?? "")
            .Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)
            .Select(int.Parse).ToArray();

        if (numbers.Length == 0)
            throw new Exception("Массив не должен быть пустым.");

        Console.Write("Какое число найти: ");
        int target = int.Parse(Console.ReadLine() ?? "");

        object sync = new();
        bool sorted = false;

        Thread sorter = new(state =>
        {
            lock (sync)
            {
                int[] data = (int[])state!;
                Array.Sort(data);

                Console.WriteLine("После сортировки: " +
                    string.Join(" ", data));

                sorted = true;
                Monitor.PulseAll(sync);
            }
        });

        Thread finder = new(state =>
        {
            int number = (int)state!;

            lock (sync)
            {
                while (!sorted)
                    Monitor.Wait(sync);

                int index = Array.BinarySearch(numbers, number);

                Console.WriteLine(index >= 0
                    ? $"Число {number} найдено. Индекс: {index}"
                    : $"Число {number} не найдено.");
            }
        });

        finder.Start(target);
        sorter.Start(numbers);

        sorter.Join();
        finder.Join();
    }
}