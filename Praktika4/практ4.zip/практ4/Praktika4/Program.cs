﻿using System;
using System.Text;
using System.Threading;

class Program
{
    delegate double MathDelegate(int n);
    delegate void LaunchDelegate();

    static int tickets, fuel;
    static ManualResetEvent calcDone = new ManualResetEvent(false);
    static ManualResetEvent fuelDone = new ManualResetEvent(false);

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine(
            "1. Диспетчер задач\n" +
            "2. Асинхронный калькулятор\n" +
            "3. Касса кинотеатра\n" +
            "4. Космический запуск");

        switch (Console.ReadLine())
        {
            case "1": Task1(); break;
            case "2": Task2(); break;
            case "3": Task3(); break;
            case "4": Task4(); break;
            default: Console.WriteLine("Неверный номер."); break;
        }
    }

    // Задание 1. Диспетчер задач
    static void Task1()
    {
        new Thread(() =>
        {
            while (true)
            {
                Console.WriteLine(DateTime.Now.ToString("HH:mm:ss"));
                Thread.Sleep(1000);
            }
        })
        { IsBackground = true }.Start();

        for (int i = 1; i <= 3; i++)
            ThreadPool.QueueUserWorkItem(state =>
            {
                int number = (int)state;
                Console.WriteLine(
                    $"Задача №{number} выполняется в потоке " +
                    Thread.CurrentThread.ManagedThreadId);
                Thread.Sleep(2000);
                Console.WriteLine($"Задача №{number} завершена.");
            }, i);

        Thread.Sleep(5000);
        Console.WriteLine("Главный поток завершён.");
    }

    // Задание 2. Асинхронный калькулятор
    static void Task2()
    {
        calcDone.Reset();
        MathDelegate calc = CalculateHeavyMath;
        calc.BeginInvoke(25, CalculationFinished, calc);

        Console.WriteLine("Расчет запущен. Главный поток свободен.");
        calcDone.WaitOne();
    }

    static double CalculateHeavyMath(int n)
    {
        Thread.Sleep(3000);
        return Math.Sqrt(n);
    }

    static void CalculationFinished(IAsyncResult ar)
    {
        try
        {
            MathDelegate calc = (MathDelegate)ar.AsyncState;
            Console.WriteLine("Результат: " + calc.EndInvoke(ar));
        }
        finally { calcDone.Set(); }
    }

    // Задание 3. Касса кинотеатра
    static void Task3()
    {
        Console.WriteLine("Без синхронизации:");
        RunCashiers(false);

        Console.WriteLine("\nEnter для запуска с синхронизацией.");
        Console.ReadLine();
        RunCashiers(true);
    }

    static void RunCashiers(bool safe)
    {
        tickets = 100;
        Thread[] threads = new Thread[5];

        for (int i = 0; i < threads.Length; i++)
        {
            threads[i] = new Thread(state =>
            {
                int number = (int)state;

                while (true)
                {
                    int left;

                    if (safe)
                    {
                        int current = Interlocked.CompareExchange(
                            ref tickets, 0, 0);

                        if (current <= 0) break;

                        if (Interlocked.CompareExchange(
                            ref tickets, current - 1, current) != current)
                            continue;

                        left = current - 1;
                        Thread.Sleep(10);
                    }
                    else
                    {
                        // Намеренная гонка данных
                        if (tickets <= 0) break;
                        Thread.Sleep(10);
                        left = --tickets;
                    }

                    Console.WriteLine(
                        $"Кассир {number} продал билет. Осталось: {left}");
                }
            });
            threads[i].Start(i + 1);
        }

        foreach (Thread thread in threads)
            thread.Join();

        Console.WriteLine("Итоговый остаток: " + tickets);
    }

    // Задание 4. Космический запуск
    static void Task4()
    {
        fuel = 0;
        calcDone.Reset();
        fuelDone.Reset();

        new Thread(() =>
        {
            while (true)
            {
                Console.WriteLine("Телеметрия в норме...");
                Thread.Sleep(1000);
            }
        })
        { IsBackground = true }.Start();

        LaunchDelegate calc = CalculateTrajectory;
        calc.BeginInvoke(TrajectoryFinished, calc);
        ThreadPool.QueueUserWorkItem(PumpFuel);

        Thread.Sleep(5000);
        fuelDone.WaitOne();
        calcDone.WaitOne();

        Console.WriteLine("Итоговый уровень топлива: " +
            Interlocked.CompareExchange(ref fuel, 0, 0));
    }

    static void CalculateTrajectory()
    {
        Thread.Sleep(4000);
    }

    static void TrajectoryFinished(IAsyncResult ar)
    {
        try
        {
            ((LaunchDelegate)ar.AsyncState).EndInvoke(ar);
            Console.WriteLine("Траектория рассчитана! К запуску готов.");
        }
        finally { calcDone.Set(); }
    }

    static void PumpFuel(object state)
    {
        for (int i = 0; i < 10; i++)
        {
            Thread.Sleep(500);
            Console.WriteLine("Топливо: " +
                Interlocked.Add(ref fuel, 10));
        }
        fuelDone.Set();
    }
}