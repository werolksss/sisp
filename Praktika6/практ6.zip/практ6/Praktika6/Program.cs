using Praktika6;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

class MainForm : Form
{
    readonly TabControl tabs = new() { Dock = DockStyle.Fill };
    readonly ManualResetEventSlim pause = new(true);
    readonly ConcurrentQueue<(int, string)> messages = new();

    CancellationTokenSource? generators, copying;
    readonly Thread[] workers = new Thread[3];
    readonly TextBox[] generated = new TextBox[3];
    readonly ComboBox[] priorities = new ComboBox[3];

    readonly System.Windows.Forms.Timer timer = new() { Interval = 150 };
    long copied, total;
    bool busy;

    public MainForm()
    {
        Text = "Практическая работа №6";
        Width = 1000;
        Height = 650;
        StartPosition = FormStartPosition.CenterScreen;
        Controls.Add(tabs);

        GeneratorsTab();
        CopyTab();
        MathTab();
        TextTab();

        timer.Tick += (_, _) =>
        {
            StringBuilder[] text =
                { new StringBuilder(), new StringBuilder(), new StringBuilder() };

            while (messages.TryDequeue(out var item))
                text[item.Item1].Append(item.Item2).Append(' ');

            for (int i = 0; i < 3; i++)
            {
                if (generated[i].TextLength > 10000)
                    generated[i].Clear();

                generated[i].AppendText(text[i].ToString());
            }
        };
        timer.Start();

        FormClosing += (_, e) =>
        {
            if (busy)
            {
                e.Cancel = true;
                copying?.Cancel();
                pause.Set();
                MessageBox.Show("Копирование останавливается. Затем закрой окно.");
                return;
            }

            StopGenerators();
            timer.Stop();
        };

        FormClosed += (_, _) =>
        {
            timer.Dispose();
            pause.Dispose();
        };
    }

    FlowLayoutPanel Page(string title)
    {
        TabPage page = new(title) { AutoScroll = true };
        FlowLayoutPanel panel = new()
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            Padding = new Padding(10)
        };
        page.Controls.Add(panel);
        tabs.TabPages.Add(page);
        return panel;
    }

    static FlowLayoutPanel Row(params Control[] controls)
    {
        FlowLayoutPanel row = new() { AutoSize = true, WrapContents = false };
        row.Controls.AddRange(controls);
        return row;
    }

    static Label Label(string text) => new() { Text = text, AutoSize = true };
    static Button Button(string text) => new() { Text = text, AutoSize = true };

    static TextBox Output(int height = 230) => new()
    {
        Width = 900,
        Height = height,
        Multiline = true,
        ReadOnly = true,
        ScrollBars = ScrollBars.Vertical
    };

    // Задание 1. Генераторы и приоритеты потоков
    void GeneratorsTab()
    {
        var page = Page("Генераторы");
        string[] names = { "Числа", "Буквы", "Символы" };

        for (int i = 0; i < 3; i++)
        {
            int index = i;
            priorities[i] = new ComboBox
            {
                Width = 150,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            priorities[i].Items.AddRange(Enum.GetNames(typeof(ThreadPriority)));
            priorities[i].SelectedItem = "Normal";

            priorities[i].SelectedIndexChanged += (_, _) =>
            {
                if (workers[index]?.IsAlive == true)
                    workers[index].Priority = Enum.Parse<ThreadPriority>(
                        priorities[index].Text);
            };

            generated[i] = Output(85);
            page.Controls.Add(Row(Label(names[i]), priorities[i]));
            page.Controls.Add(generated[i]);
        }

        var start = Button("Запустить");
        var stop = Button("Остановить");
        page.Controls.Add(Row(start, stop));

        start.Click += (_, _) =>
        {
            StopGenerators();
            generators = new CancellationTokenSource();
            CancellationToken token = generators.Token;

            for (int i = 0; i < 3; i++)
            {
                int index = i;
                generated[i].Clear();

                workers[i] = new Thread(() =>
                {
                    const string letters = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
                    const string symbols = "!@#$%^&*()_+-=?";

                    while (!token.IsCancellationRequested)
                    {
                        string value = index switch
                        {
                            0 => Random.Shared.Next(1000).ToString(),
                            1 => letters[Random.Shared.Next(letters.Length)].ToString(),
                            _ => symbols[Random.Shared.Next(symbols.Length)].ToString()
                        };

                        messages.Enqueue((index, value));
                        if (token.WaitHandle.WaitOne(100)) break;
                    }
                })
                {
                    IsBackground = true,
                    Priority = Enum.Parse<ThreadPriority>(priorities[i].Text)
                };

                workers[i].Start();
            }
        };

        stop.Click += (_, _) => StopGenerators();
    }

    void StopGenerators()
    {
        if (generators == null) return;

        generators.Cancel();
        foreach (Thread thread in workers)
            if (thread != null) thread.Join();

        generators.Dispose();
        generators = null;
        while (messages.TryDequeue(out _)) { }
    }

    // Задания 2–5. Копирование, пауза и остановка
    void CopyTab()
    {
        var page = Page("Копирование");
        var folder = new CheckBox { Text = "Копировать папку", AutoSize = true };
        var source = new TextBox { Width = 700 };
        var destination = new TextBox { Width = 700 };
        var selectSource = Button("Выбрать источник");
        var selectDestination = Button("Куда копировать");
        var count = new NumericUpDown { Minimum = 1, Maximum = 32, Value = 4 };
        var start = Button("Старт");
        var hold = Button("Пауза");
        var stop = Button("Остановить");
        var progress = new ProgressBar { Width = 900, Maximum = 1000 };
        var status = Output(100);

        hold.Enabled = stop.Enabled = false;

        page.Controls.Add(folder);
        page.Controls.Add(Row(source, selectSource));
        page.Controls.Add(Row(destination, selectDestination));
        page.Controls.Add(Row(Label("Потоки:"), count, start, hold, stop));
        page.Controls.Add(progress);
        page.Controls.Add(status);

        selectSource.Click += (_, _) =>
        {
            if (folder.Checked)
            {
                using var dialog = new FolderBrowserDialog();
                if (dialog.ShowDialog() == DialogResult.OK)
                    source.Text = dialog.SelectedPath;
            }
            else
            {
                using var dialog = new OpenFileDialog();
                if (dialog.ShowDialog() == DialogResult.OK)
                    source.Text = dialog.FileName;
            }
        };

        selectDestination.Click += (_, _) =>
        {
            using var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
                destination.Text = dialog.SelectedPath;
        };

        hold.Click += (_, _) =>
        {
            if (pause.IsSet)
            {
                pause.Reset();
                hold.Text = "Продолжить";
            }
            else
            {
                pause.Set();
                hold.Text = "Пауза";
            }
        };

        stop.Click += (_, _) =>
        {
            copying?.Cancel();
            pause.Set();
            hold.Enabled = stop.Enabled = false;
            status.Text = "Останавливаем копирование...";
        };

        start.Click += async (_, _) =>
        {
            string from, target;
            bool isFolder = folder.Checked;
            int threads = (int)count.Value;

            try
            {
                from = Path.GetFullPath(source.Text.Trim());
                target = Path.GetFullPath(destination.Text.Trim());

                if (isFolder ? !Directory.Exists(from) : !File.Exists(from))
                    throw new Exception("Источник не найден.");
                if (!Directory.Exists(target))
                    throw new Exception("Выбери существующую папку назначения.");

                if (isFolder)
                {
                    string prefix = Path.TrimEndingDirectorySeparator(from) +
                                    Path.DirectorySeparatorChar;

                    if (string.Equals(Path.TrimEndingDirectorySeparator(from),
                            Path.TrimEndingDirectorySeparator(target),
                            StringComparison.OrdinalIgnoreCase) ||
                        target.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                        throw new Exception("Нельзя копировать папку внутрь самой себя.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            Control[] inputs =
                { source, destination, selectSource, selectDestination, count, folder, start };

            foreach (Control control in inputs) control.Enabled = false;
            busy = true;
            copied = total = 0;
            progress.Value = 0;
            pause.Set();
            hold.Text = "Пауза";
            hold.Enabled = stop.Enabled = true;
            copying = new CancellationTokenSource();

            using var update = new System.Windows.Forms.Timer { Interval = 150 };
            update.Tick += (_, _) =>
            {
                long size = Interlocked.Read(ref total);
                long done = Interlocked.Read(ref copied);

                progress.Value = size == 0 ? 0 :
                    (int)Math.Clamp(done * 1000.0 / size, 0, 1000);

                if (!copying.IsCancellationRequested)
                    status.Text = $"{(pause.IsSet ? "Копирование" : "Пауза")}: " +
                        $"{done / 1048576.0:F2} из {size / 1048576.0:F2} МБ";
            };
            update.Start();

            try
            {
                CancellationToken token = copying.Token;
                string result = await Task.Run(() =>
                    Copy(from, target, isFolder, threads, token));

                update.Stop();
                progress.Value = 1000;
                status.Text = "Готово:\r\n" + result;
            }
            catch (Exception ex)
            {
                update.Stop();
                status.Text = copying.IsCancellationRequested
                    ? "Копирование остановлено. Можно выбрать другой источник."
                    : "Ошибка: " + ex.Message;
            }
            finally
            {
                busy = false;
                hold.Enabled = stop.Enabled = false;
                foreach (Control control in inputs) control.Enabled = true;
                copying.Dispose();
                copying = null;
            }
        };
    }

    string Copy(string source, string destination, bool folder,
                int threads, CancellationToken token)
    {
        // Отдельная папка результата защищает существующие файлы
        string result = Path.Combine(destination, "Копия_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(result);

        try
        {
            if (!folder)
            {
                Interlocked.Exchange(ref total, new FileInfo(source).Length);
                CopyFileParts(source, Path.Combine(result, Path.GetFileName(source)),
                    threads, token);
            }
            else
            {
                string root = Path.Combine(result,
                    new DirectoryInfo(source).Name.TrimEnd(':') is string name &&
                    name.Length > 0 ? name : "Папка");
                Directory.CreateDirectory(root);

                var options = new EnumerationOptions
                {
                    RecurseSubdirectories = true,
                    IgnoreInaccessible = false,
                    AttributesToSkip = FileAttributes.ReparsePoint
                };

                string[] files = Directory.GetFiles(source, "*", options);

                foreach (string dir in Directory.EnumerateDirectories(source, "*", options))
                {
                    pause.Wait(token);
                    Directory.CreateDirectory(Path.Combine(root,
                        Path.GetRelativePath(source, dir)));
                }

                Interlocked.Exchange(ref total,
                    files.Sum(file => new FileInfo(file).Length));

                Parallel.ForEach(files, new ParallelOptions
                {
                    MaxDegreeOfParallelism = threads,
                    CancellationToken = token
                }, file =>
                {
                    pause.Wait(token);
                    string output = Path.Combine(root, Path.GetRelativePath(source, file));
                    CopyFileParts(file, output, 1, token);
                });
            }

            token.ThrowIfCancellationRequested();
            return result;
        }
        catch (Exception error)
        {
            try { Directory.Delete(result, true); }
            catch (Exception cleanup)
            {
                throw new IOException(
                    "Осталась незавершённая копия: " + result +
                    ". Причина: " + cleanup.Message, error);
            }
            throw;
        }
    }

    void CopyFileParts(string source, string destination,
                       int threads, CancellationToken token)
    {
        using var input = File.OpenHandle(source, FileMode.Open,
            FileAccess.Read, FileShare.Read);
        using var output = File.OpenHandle(destination, FileMode.CreateNew,
            FileAccess.Write, FileShare.None);

        long length = RandomAccess.GetLength(input);
        RandomAccess.SetLength(output, length);

        Parallel.For(0, threads, new ParallelOptions
        {
            MaxDegreeOfParallelism = threads,
            CancellationToken = token
        }, part =>
        {
            long position = length / threads * part;
            long end = part == threads - 1 ? length : length / threads * (part + 1);
            byte[] buffer = new byte[1024 * 1024];

            while (position < end)
            {
                pause.Wait(token);
                int size = (int)Math.Min(buffer.Length, end - position);
                int read = RandomAccess.Read(input, buffer.AsSpan(0, size), position);

                if (read == 0) throw new IOException("Источник неожиданно закончился.");

                RandomAccess.Write(output, buffer.AsSpan(0, read), position);
                position += read;
                Interlocked.Add(ref copied, read);
            }
        });
    }

    // Задание 6. Асинхронный факториал
    // Задание 7. Асинхронное возведение в степень
    void MathTab()
    {
        var page = Page("Вычисления");
        var number = new TextBox { Text = "5", Width = 180 };
        var power = new NumericUpDown { Maximum = 10000, Value = 3 };
        var factorial = Button("Факториал");
        var exponent = Button("Возвести в степень");
        var output = Output(350);

        page.Controls.Add(Row(Label("Целое число:"), number));
        page.Controls.Add(Row(Label("Целая степень ≥ 0:"), power));
        page.Controls.Add(Row(factorial, exponent));
        page.Controls.Add(output);

        async Task Calculate(bool fact)
        {
            if (!BigInteger.TryParse(number.Text, out BigInteger value))
            {
                MessageBox.Show("Введи целое число.");
                return;
            }

            if (fact && (value < 0 || value > 10000))
            {
                MessageBox.Show("Для факториала введи число от 0 до 10000.");
                return;
            }

            int degree = (int)power.Value;
            if (!fact && number.Text.Length > 1000)
            {
                MessageBox.Show("Основание должно содержать не более 1000 символов.");
                return;
            }

            factorial.Enabled = exponent.Enabled = false;
            output.Text = "Вычисление...";

            try
            {
                string result = await Task.Run(() =>
                {
                    BigInteger answer = BigInteger.One;

                    if (fact)
                        for (int i = 2; i <= (int)value; i++) answer *= i;
                    else
                        answer = BigInteger.Pow(value, degree);

                    return answer.ToString();
                });

                if (!IsDisposed) output.Text = result;
            }
            catch (Exception ex)
            {
                if (!IsDisposed) output.Text = ex.Message;
            }
            finally
            {
                if (!IsDisposed) factorial.Enabled = exponent.Enabled = true;
            }
        }

        factorial.Click += async (_, _) => await Calculate(true);
        exponent.Click += async (_, _) => await Calculate(false);
    }

    // Задание 8. Анализ текста
    void TextTab()
    {
        var page = Page("Текст");
        var input = Output();
        input.ReadOnly = false;
        var run = Button("Подсчитать");
        var output = Output(120);

        page.Controls.Add(Label("Русский или английский текст:"));
        page.Controls.Add(input);
        page.Controls.Add(run);
        page.Controls.Add(output);

        run.Click += async (_, _) =>
        {
            string text = input.Text;
            run.Enabled = false;

            try
            {
                string result = await Task.Run(() =>
                {
                    const string vowels = "аеёиоуыэюяaeiou";
                    const string consonants = "бвгджзйклмнпрстфхцчшщbcdfghjklmnpqrstvwxyz";
                    int v = 0, c = 0, symbols = 0;

                    foreach (var rune in text.EnumerateRunes())
                    {
                        symbols++;
                        var lower = Rune.ToLowerInvariant(rune);

                        if (lower.IsBmp)
                        {
                            char ch = (char)lower.Value;
                            if (vowels.Contains(ch)) v++;
                            else if (consonants.Contains(ch)) c++;
                        }
                    }

                    return $"Гласных: {v}\r\nСогласных: {c}\r\n" +
                           $"Всего символов, включая пробелы: {symbols}";
                });

                if (!IsDisposed) output.Text = result;
            }
            catch (Exception ex)
            {
                if (!IsDisposed) output.Text = ex.Message;
            }
            finally
            {
                if (!IsDisposed) run.Enabled = true;
            }
        };
    }
}