﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

class Program
{
    [STAThread]
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        while (true)
        {
            Console.WriteLine(
                "\n1. Числа от 0 до 50\n" +
                "2. Свой диапазон\n" +
                "3. Несколько потоков\n" +
                "4. Анализ 10000 чисел\n" +
                "5. Анализ и запись в файл\n" +
                "6. Диапазон в окне\n" +
                "7. Анализ чисел в окне\n" +
                "0. Выход");

            Console.Write("Выберите задание: ");
            string choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1":
                        Task1();
                        break;
                    case "2":
                        Task2();
                        break;
                    case "3":
                        Task3();
                        break;
                    case "4":
                        Task4(false);
                        break;
                    case "5":
                        Task4(true);
                        break;
                    case "6":
                        using (Form window = CreateWindow(false))
                            window.ShowDialog();
                        break;
                    case "7":
                        using (Form window = CreateWindow(true))
                            window.ShowDialog();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Неверный номер.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
        }
    }

    // Задание 1. Числа от 0 до 50
    static void Task1()
    {
        PrintNumbers(0, 50, 1, Console.WriteLine);
    }

    // Задание 2. Границы диапазона
    static void Task2()
    {
        int start = ReadNumber("Начало: ");
        int end = ReadNumber("Конец: ");

        CheckRange(start, end, 1);
        PrintNumbers(start, end, 1, Console.WriteLine);
    }

    // Задание 3. Количество потоков
    static void Task3()
    {
        int start = ReadNumber("Начало: ");
        int end = ReadNumber("Конец: ");
        int count = ReadNumber("Количество потоков: ");

        CheckRange(start, end, count);
        PrintNumbers(start, end, count, Console.WriteLine);
    }

    static int ReadNumber(string message)
    {
        Console.Write(message);
        int value;

        while (!int.TryParse(Console.ReadLine(), out value))
            Console.Write("Введите целое число: ");

        return value;
    }

    static void CheckRange(int start, int end, int count)
    {
        if (start > end)
            throw new Exception("Начало должно быть не больше конца.");

        if (count < 1 || count > 100)
            throw new Exception("Количество потоков: от 1 до 100.");

        if ((long)end - start + 1 > 10000)
            throw new Exception("Выберите диапазон до 10000 чисел.");
    }

    static void PrintNumbers(
        int start, int end, int count, Action<string> output)
    {
        Thread[] threads = new Thread[count];

        for (int i = 0; i < count; i++)
        {
            int number = i + 1;

            threads[i] = new Thread(() =>
            {
                for (long n = start; n <= end; n++)
                    output($"Поток {number}: {n}");
            });

            threads[i].Start();
        }

        foreach (Thread thread in threads)
            thread.Join();
    }

    // Задание 4. Минимум, максимум и среднее
    static void Task4(bool save)
    {
        NumberSet data = new NumberSet();
        data.Calculate();

        Console.WriteLine(data.Results());

        // Задание 5. Запись набора и результатов в файл
        if (save)
        {
            Console.Write(
                "\nПуть к файлу (Enter — новая запись в Документах): ");

            string path = (Console.ReadLine() ?? "").Trim().Trim('"');

            if (path == "")
            {
                path = Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.MyDocuments),
                    "numbers_" +
                    DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") +
                    ".txt");
            }

            path = Path.GetFullPath(path);

            if (File.Exists(path))
            {
                Console.Write("Файл существует. Перезаписать? д/н: ");

                if (!string.Equals(
                    Console.ReadLine(), "д",
                    StringComparison.OrdinalIgnoreCase))
                    return;
            }

            data.Save(path);
            Console.WriteLine("Сохранено: " + path);
        }
    }

    class NumberSet
    {
        public int[] Numbers = new int[10000];
        int min, max;
        double average;

        public NumberSet()
        {
            Random random = new Random();

            for (int i = 0; i < Numbers.Length; i++)
                Numbers[i] = random.Next(-1000, 1001);
        }

        public void Calculate()
        {
            // Для каждого вычисления выделен отдельный поток
            Thread a = new Thread(() => min = Numbers.Min());
            Thread b = new Thread(() => max = Numbers.Max());
            Thread c = new Thread(() => average = Numbers.Average());

            a.Start();
            b.Start();
            c.Start();

            a.Join();
            b.Join();
            c.Join();
        }

        public string Results()
        {
            return $"Количество: {Numbers.Length}\r\n" +
                   $"Минимум: {min}\r\n" +
                   $"Максимум: {max}\r\n" +
                   $"Среднее: {average:F4}";
        }

        public void Save(string path)
        {
            Exception error = null;

            // Запись выполняет отдельный поток
            Thread writer = new Thread(() =>
            {
                try
                {
                    File.WriteAllText(
                        path,
                        "Набор чисел:\r\n" +
                        string.Join(" ", Numbers) +
                        "\r\n\r\n" + Results(),
                        Encoding.UTF8);
                }
                catch (Exception ex)
                {
                    error = ex;
                }
            });

            writer.Start();
            writer.Join();

            if (error != null)
                throw new IOException("Не удалось сохранить файл.", error);
        }
    }

    // Задание 6. Диапазон и потоки в оконном интерфейсе
    // Задание 7. Анализ чисел и запись в файл в оконном интерфейсе
    static Form CreateWindow(bool analysis)
    {
        Form form = new Form
        {
            Text = analysis
                ? "Задание 7. Анализ чисел"
                : "Задание 6. Диапазон и потоки",
            ClientSize = new Size(850, 550),
            StartPosition = FormStartPosition.CenterScreen
        };

        FlowLayoutPanel panel = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 80,
            Padding = new Padding(8)
        };

        TextBox output = new TextBox
        {
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Both,
            WordWrap = false,
            Dock = DockStyle.Fill
        };

        Button run = new Button
        {
            Text = analysis ? "Создать и вычислить" : "Запустить",
            AutoSize = true
        };

        Button save = new Button
        {
            Text = "Сохранить в файл",
            AutoSize = true,
            Enabled = false
        };

        NumericUpDown start = new NumericUpDown
        {
            Minimum = int.MinValue,
            Maximum = int.MaxValue,
            Value = 0,
            Width = 110
        };

        NumericUpDown end = new NumericUpDown
        {
            Minimum = int.MinValue,
            Maximum = int.MaxValue,
            Value = 50,
            Width = 110
        };

        NumericUpDown count = new NumericUpDown
        {
            Minimum = 1,
            Maximum = 100,
            Value = 1,
            Width = 60
        };

        if (!analysis)
        {
            panel.Controls.Add(new Label
            { Text = "Начало:", AutoSize = true });
            panel.Controls.Add(start);
            panel.Controls.Add(new Label
            { Text = "Конец:", AutoSize = true });
            panel.Controls.Add(end);
            panel.Controls.Add(new Label
            { Text = "Потоки:", AutoSize = true });
            panel.Controls.Add(count);
        }

        panel.Controls.Add(run);

        if (analysis)
            panel.Controls.Add(save);

        form.Controls.Add(output);
        form.Controls.Add(panel);

        NumberSet data = null;
        bool busy = false;

        // Не закрываем окно в середине вычисления или записи
        form.FormClosing += (sender, e) =>
        {
            if (busy)
            {
                e.Cancel = true;
                MessageBox.Show("Дождитесь завершения операции.");
            }
        };

        run.Click += async (sender, e) =>
        {
            busy = true;
            run.Enabled = false;
            save.Enabled = false;
            output.Text = "Выполняется...";

            try
            {
                if (analysis)
                {
                    data = null;

                    NumberSet calculated = await Task.Run(() =>
                    {
                        NumberSet set = new NumberSet();
                        set.Calculate();
                        return set;
                    });

                    data = calculated;
                    output.Text = data.Results() +
                        "\r\n\r\nНабор чисел:\r\n" +
                        string.Join(" ", data.Numbers);
                }
                else
                {
                    int first = (int)start.Value;
                    int last = (int)end.Value;
                    int total = (int)count.Value;

                    CheckRange(first, last, total);

                    string text = await Task.Run(() =>
                    {
                        StringBuilder result = new StringBuilder();
                        object sync = new object();

                        PrintNumbers(first, last, total, line =>
                        {
                            lock (sync)
                                result.AppendLine(line);
                        });

                        return result.ToString();
                    });

                    output.Text = text;
                }
            }
            catch (Exception ex)
            {
                output.Text = "Ошибка: " + ex.Message;
            }
            finally
            {
                busy = false;
                run.Enabled = true;
                save.Enabled = analysis && data != null;
            }
        };

        save.Click += async (sender, e) =>
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "Текстовый файл|*.txt";
                dialog.FileName = "numbers.txt";

                if (dialog.ShowDialog(form) != DialogResult.OK)
                    return;

                busy = true;
                run.Enabled = false;
                save.Enabled = false;

                try
                {
                    string path = dialog.FileName;
                    await Task.Run(() => data.Save(path));
                    MessageBox.Show("Сохранено:\n" + path);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
                finally
                {
                    busy = false;
                    run.Enabled = true;
                    save.Enabled = true;
                }
            }
        };

        return form;
    }
}