﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyLibrary
{
    internal class Class1
    {
    }
}
