﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.WriteLine(
            "1. Единственный экземпляр\n2. Общий счётчик\n" +
            "3. Ограничение потоков\n4. Производитель и потребители\n" +
            "5. Стартовый сигнал\n6. Поочерёдный вывод");
        Console.Write("Номер задания: ");

        switch (Console.ReadLine())
        {
            case "1": Task1(); return;
            case "2": Task2(); break;
            case "3": Task3(); break;
            case "4": Task4(); break;
            case "5": Task5(); break;
            case "6": Task6(); break;
            default: Console.WriteLine("Неверный номер."); break;
        }

        Console.WriteLine("\nНажмите Enter для выхода.");
        Console.ReadLine();
    }

    // Задание 1. Единственный экземпляр приложения
    static void Task1()
    {
        try
        {
            using Mutex existing = Mutex.OpenExisting("MY_MUTEX");
            Console.WriteLine("Приложение уже запущено!");
            return;
        }
        catch (WaitHandleCannotBeOpenedException)
        {
            // Мьютекс ещё не существует
        }

        // created защищает от одновременного запуска двух экземпляров
        using Mutex mutex = new(true, "MY_MUTEX", out bool created);

        if (!created)
        {
            Console.WriteLine("Приложение уже запущено!");
            return;
        }

        try
        {
            Console.WriteLine("Приложение работает");
            Console.WriteLine("Нажмите любую клавишу для выхода.");
            Console.ReadKey(true);
        }
        finally
        {
            mutex.ReleaseMutex();
        }
    }

    // Задание 2. Защита общего счётчика
    class MutexCounter : IDisposable
    {
        int count;
        readonly Mutex mutex = new();

        public int Count => count;

        public void Increment()
        {
            for (int i = 0; i < 1_000_000; i++)
            {
                mutex.WaitOne();
                try { count++; }
                finally { mutex.ReleaseMutex(); }
            }
        }

        public void Dispose() => mutex.Dispose();
    }

    static void Task2()
    {
        using MutexCounter counter = new();
        Thread[] threads = Enumerable.Range(0, 5)
            .Select(_ => new Thread(counter.Increment)).ToArray();

        Console.WriteLine("Работают 5 потоков. Подождите...");
        foreach (Thread t in threads) t.Start();
        foreach (Thread t in threads) t.Join();

        Console.WriteLine("Итоговый счётчик: " + counter.Count);
    }

    // Задание 3. Не более трёх потоков одновременно
    static void Task3()
    {
        using Semaphore semaphore = new(3, 3);
        using CountdownEvent finished = new(6);
        object sync = new();
        int active = 0, maximum = 0;

        ThreadPool.GetMinThreads(out int oldMin, out int ioMin);
        ThreadPool.SetMinThreads(Math.Max(oldMin, 6), ioMin);

        try
        {
            for (int i = 1; i <= 6; i++)
            {
                int number = i;

                ThreadPool.QueueUserWorkItem(_ =>
                {
                    try
                    {
                        while (!semaphore.WaitOne(500))
                            Console.WriteLine(
                                $"Задача {number}: таймаут, повторная попытка.");

                        try
                        {
                            lock (sync)
                            {
                                active++;
                                maximum = Math.Max(maximum, active);
                                Console.WriteLine(
                                    $"Задача {number}, поток " +
                                    $"{Thread.CurrentThread.ManagedThreadId}: " +
                                    $"начало. Работают: {active}");
                            }

                            Thread.Sleep(2000);
                        }
                        finally
                        {
                            lock (sync)
                            {
                                active--;
                                Console.WriteLine(
                                    $"Задача {number}: завершена. Работают: {active}");
                            }
                            semaphore.Release();
                        }
                    }
                    finally { finished.Signal(); }
                });
            }

            finished.Wait();
            Console.WriteLine("Максимум одновременно работавших: " + maximum);
        }
        finally
        {
            ThreadPool.SetMinThreads(oldMin, ioMin);
        }
    }

    // Задание 4. Ограниченная очередь
    static void Task4()
    {
        Console.Write("Количество элементов N: ");
        if (!int.TryParse(Console.ReadLine(), out int n) || n < 1)
        {
            Console.WriteLine("Введите положительное целое число.");
            return;
        }

        Queue<int> queue = new();
        object sync = new();
        using Semaphore empty = new(5, 5);
        using Semaphore full = new(0, 5);
        int processed = 0;

        void Put(int value)
        {
            empty.WaitOne();
            lock (sync)
            {
                queue.Enqueue(value);
                Console.WriteLine(
                    $"Добавлено: {(value == -1 ? "СТОП" : value.ToString())}. " +
                    $"В очереди: {queue.Count}");
            }
            full.Release();
        }

        void Consume(int number)
        {
            while (true)
            {
                full.WaitOne();
                int value;

                lock (sync)
                {
                    value = queue.Dequeue();
                    Console.WriteLine(
                        $"Потребитель {number} забрал: " +
                        $"{(value == -1 ? "СТОП" : value.ToString())}. " +
                        $"В очереди: {queue.Count}");
                }
                empty.Release();

                if (value == -1) return;

                Thread.Sleep(100);
                Interlocked.Increment(ref processed);
                Console.WriteLine(
                    $"Потребитель {number} обработал {value}.");
            }
        }

        Thread producer = new(() =>
        {
            for (long i = 1; i <= n; i++)
                Put((int)i);

            // По одному сигналу завершения для каждого потребителя
            Put(-1);
            Put(-1);
        });

        Thread first = new(() => Consume(1));
        Thread second = new(() => Consume(2));

        first.Start();
        second.Start();
        producer.Start();

        producer.Join();
        first.Join();
        second.Join();

        Console.WriteLine($"Обработано: {processed} из {n}.");
    }

    // Задание 5. Общий старт и повторная блокировка
    static void Task5()
    {
        using ManualResetEvent startEvent = new(false);

        Thread[] threads = Enumerable.Range(1, 10).Select(number =>
            new Thread(() =>
            {
                startEvent.WaitOne();
                Console.WriteLine($"Поток {number} стартовал");
            })).ToArray();

        foreach (Thread t in threads) t.Start();

        // Убеждаемся, что все потоки уже вошли в ожидание
        SpinWait.SpinUntil(() => threads.All(t =>
            (t.ThreadState & ThreadState.WaitSleepJoin) != 0));

        Console.WriteLine("10 потоков ожидают. Через 2 секунды — Set().");
        Thread.Sleep(2000);
        startEvent.Set();

        foreach (Thread t in threads) t.Join();

        // Сбрасываем событие после завершения первой группы
        startEvent.Reset();
        Console.WriteLine("\nReset(): новый поток снова будет ждать.");

        Thread extra = new(() =>
        {
            startEvent.WaitOne();
            Console.WriteLine("Поток 11 стартовал");
        });

        extra.Start();

        SpinWait.SpinUntil(() =>
            (extra.ThreadState & ThreadState.WaitSleepJoin) != 0);

        Console.WriteLine("Поток 11 ожидает. Через 2 секунды — новый Set().");
        Thread.Sleep(2000);
        startEvent.Set();
        extra.Join();
    }

    // Задание 6. Чередование нечётных и чётных чисел
    static void Task6()
    {
        using AutoResetEvent event1 = new(true);
        using AutoResetEvent event2 = new(false);

        Thread odd = new(() =>
        {
            for (int i = 1; i <= 9; i += 2)
            {
                event1.WaitOne();
                Console.Write(i + " ");
                event2.Set();
            }
        });

        Thread even = new(() =>
        {
            for (int i = 2; i <= 10; i += 2)
            {
                event2.WaitOne();
                Console.Write(i + " ");
                event1.Set();
            }
        });

        odd.Start();
        even.Start();
        odd.Join();
        even.Join();
        Console.WriteLine();
    }
}